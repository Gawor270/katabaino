Pixel Camping Pack (32x32)

Author: Vitalyez

This pack contains 8 pixel art camping-themed assets for 2D games.

Contents:
- 3 trees
- Open tent
- Closed tent
- Tree stump
- Cooking pot
- Wooden crate
- 32x32 pixels each
- Transparent background

License:
You are free to:
- Use in personal and commercial projects
- Modify the assets
- Share the assets

Attribution is not required, but appreciated.